package com.gestao.financas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinancasApplicationTests {

	@Test
	void contextLoads() {
	}

}
